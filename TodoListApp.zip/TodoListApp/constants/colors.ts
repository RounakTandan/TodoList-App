const colors = {
  primary: '#007AFF',
  secondary: '#b0c4de',
  error: '#ff3b30',
  background: '#fff',
  text: '#222',
  gray: '#888',
};

export default colors; 