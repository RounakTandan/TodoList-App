import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

type Task = {
  id: string;
  text: string;
  completed: boolean;
};

type Props = {
  task: Task;
  onDelete: () => void;
  onToggle: () => void;
};

const TaskItem: React.FC<Props> = ({ task, onDelete, onToggle }) => (
  <View style={styles.container}>
    <TouchableOpacity onPress={onToggle} style={styles.checkBox}>
      <Ionicons
        name={task.completed ? 'checkbox' : 'square-outline'}
        size={24}
        color={task.completed ? '#007AFF' : '#ccc'}
      />
    </TouchableOpacity>
    <Text style={[styles.text, task.completed && styles.completed]}>{task.text}</Text>
    <TouchableOpacity onPress={onDelete} style={styles.deleteButton}>
      <Ionicons name="trash" size={20} color="#ff3b30" />
    </TouchableOpacity>
  </View>
);

const styles = StyleSheet.create({
  container: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  checkBox: { marginRight: 12 },
  text: { flex: 1, fontSize: 16 },
  completed: { textDecorationLine: 'line-through', color: '#888' },
  deleteButton: { marginLeft: 12 },
});

export default TaskItem; 