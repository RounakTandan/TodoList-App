import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  apiKey: 'AIzaSyBLlKSi5IGSSaQoUo1Fp1dkJ38GlYLQSrA',
  authDomain: 'todolist-fdd83.firebaseapp.com',
  projectId: 'todolist-fdd83',
  storageBucket: 'todolist-fdd83.appspot.com',
  messagingSenderId: '424375357049',
  appId: '1:424375357049:web:199d283d9fd6b5291bcea8'
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const storage = getStorage(app);
