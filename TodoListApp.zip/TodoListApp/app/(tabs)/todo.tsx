import React, { useState } from 'react';
import { View, Text, FlatList, StyleSheet, TextInput } from 'react-native';
import CustomButton from '../../components/CustomButton';
import TaskItem from '../../components/TaskItem';
import { useTasks } from '../../hooks/useTasks';

const TodoScreen = () => {
  const { tasks, addTask, deleteTask, toggleTask, loading, error } = useTasks();
  const [newTask, setNewTask] = useState('');

  const handleAddTask = () => {
    if (newTask.trim()) {
      addTask(newTask.trim());
      setNewTask('');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>My To-Do List</Text>
      <View style={styles.inputRow}>
        <TextInput
          style={styles.input}
          placeholder="Add a new task"
          value={newTask}
          onChangeText={setNewTask}
        />
        <CustomButton title="Add" onPress={handleAddTask} disabled={!newTask.trim()} />
      </View>
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <FlatList
        data={tasks}
        keyExtractor={item => item.id}
        renderItem={({ item }) => (
          <TaskItem
            task={item}
            onDelete={() => deleteTask(item.id)}
            onToggle={() => toggleTask(item.id)}
          />
        )}
        refreshing={loading}
        onRefresh={() => {}}
        ListEmptyComponent={<Text style={styles.empty}>No tasks yet.</Text>}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 16 },
  inputRow: { flexDirection: 'row', alignItems: 'center', marginBottom: 16 },
  input: { flex: 1, borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 12, marginRight: 8 },
  error: { color: 'red', marginBottom: 8 },
  empty: { textAlign: 'center', color: '#888', marginTop: 32 },
});

export default TodoScreen; 