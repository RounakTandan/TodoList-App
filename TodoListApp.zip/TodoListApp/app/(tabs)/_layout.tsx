import React from 'react';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import TodoScreen from './todo';
import ProfileScreen from './profile';
import { Ionicons } from '@expo/vector-icons';

const Tab = createBottomTabNavigator();

const TabLayout = () => (
  <Tab.Navigator
    screenOptions={({ route }) => ({
      tabBarIcon: ({ color, size }) => {
        let iconName = '';
        if (route.name === 'To-Do') iconName = 'checkmark-done-outline';
        else if (route.name === 'Profile') iconName = 'person-circle-outline';
        return <Ionicons name={iconName as any} size={size} color={color} />;
      },
      tabBarActiveTintColor: '#007AFF',
      tabBarInactiveTintColor: 'gray',
      headerShown: false,
    })}
  >
    <Tab.Screen name="To-Do" component={TodoScreen} />
    <Tab.Screen name="Profile" component={ProfileScreen} />
  </Tab.Navigator>
);

export default TabLayout; 