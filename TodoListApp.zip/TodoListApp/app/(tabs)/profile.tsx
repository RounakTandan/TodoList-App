import React, { useState } from 'react';
import { View, Text, TextInput, Image, TouchableOpacity, StyleSheet, ActivityIndicator } from 'react-native';
import { useAuth } from '../../hooks/useAuth';
import { useNavigation } from '@react-navigation/native';
import * as ImagePicker from 'expo-image-picker';
import { updateProfile } from 'firebase/auth';
import { uploadProfileImage, updateUsername } from '../../firebase/firebaseConfig';

const ProfileScreen = () => {
  const { user, logout, setUser } = useAuth();
  const navigation = useNavigation();
  const [username, setUsername] = useState(user?.displayName || '');
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');

  const handleImagePick = async () => {
    setError('');
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Images, allowsEditing: true, aspect: [1, 1], quality: 0.7 });
    if (!result.canceled && result.assets && result.assets.length > 0) {
      setUploading(true);
      try {
        const url = await uploadProfileImage(user.uid, result.assets[0].uri);
        await updateProfile(user, { photoURL: url });
        setUser({ ...user, photoURL: url });
      } catch (err: any) {
        setError(err.message);
      } finally {
        setUploading(false);
      }
    }
  };

  const handleUsernameChange = async () => {
    setError('');
    setUploading(true);
    try {
      await updateUsername(user, username);
      setUser({ ...user, displayName: username });
    } catch (err: any) {
      setError(err.message);
    } finally {
      setUploading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Profile</Text>
      <TouchableOpacity onPress={handleImagePick}>
        <Image source={user?.photoURL ? { uri: user.photoURL } : require('../../assets/images/default-profile.png')} style={styles.avatar} />
        {uploading && <ActivityIndicator style={styles.avatarLoader} />}
      </TouchableOpacity>
      <Text style={styles.label}>Email</Text>
      <Text style={styles.value}>{user?.email}</Text>
      <Text style={styles.label}>Username</Text>
      <TextInput
        style={styles.input}
        value={username}
        onChangeText={setUsername}
        onBlur={handleUsernameChange}
      />
      {error ? <Text style={styles.error}>{error}</Text> : null}
      <TouchableOpacity style={styles.logoutButton} onPress={logout}>
        <Text style={styles.logoutText}>Logout</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: { flex: 1, alignItems: 'center', padding: 20, backgroundColor: '#fff' },
  title: { fontSize: 28, fontWeight: 'bold', marginBottom: 24 },
  avatar: { width: 100, height: 100, borderRadius: 50, marginBottom: 16, backgroundColor: '#eee' },
  avatarLoader: { position: 'absolute', top: 50, left: 50 },
  label: { fontWeight: 'bold', marginTop: 12 },
  value: { marginBottom: 8 },
  input: { width: 200, borderWidth: 1, borderColor: '#ccc', borderRadius: 8, padding: 10, marginBottom: 12 },
  logoutButton: { backgroundColor: '#ff3b30', padding: 12, borderRadius: 8, marginTop: 24 },
  logoutText: { color: '#fff', fontWeight: 'bold' },
  error: { color: 'red', marginTop: 8 },
});

export default ProfileScreen; 