import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const NotFound = () => (
  <View style={styles.container}>
    <Text style={styles.text}>404 - Page Not Found</Text>
  </View>
);

const styles = StyleSheet.create({
  container: { flex: 1, justifyContent: 'center', alignItems: 'center', backgroundColor: '#fff' },
  text: { fontSize: 24, color: '#888' },
});

export default NotFound; 