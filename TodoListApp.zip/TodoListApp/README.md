# TodoListApp

A complete React Native To-Do App built with Expo and TypeScript, featuring Firebase authentication, Firestore real-time tasks, and profile management with image upload.

## Features

- Email/password authentication (Firebase Auth)
- Real-time to-do list (Firestore, user-specific)
- Add, delete, mark complete/incomplete
- Profile tab: username, email, profile image (Firebase Storage)
- Change username and upload profile image
- Logout functionality
- Modular, clean, production-ready code

## Folder Structure

```
TodoListApp/
├── app/
│   ├── (auth)/
│   │   ├── login.tsx
│   │   └── register.tsx
│   ├── (tabs)/
│   │   ├── todo.tsx
│   │   ├── profile.tsx
│   │   └── _layout.tsx
│   └── +not-found.tsx
├── assets/
│   ├── images/
│   └── fonts/
├── components/
│   ├── TaskItem.tsx
│   └── CustomButton.tsx
├── constants/
│   └── colors.ts
├── firebase/
│   └── firebaseConfig.ts
├── hooks/
│   ├── useAuth.ts
│   └── useTasks.ts
├── README.md
├── app.json
├── tsconfig.json
├── package.json
├── package-lock.json
```

## Setup Instructions

### 1. Clone the Repository

```
git clone <repo-url>
cd TodoListApp
```

### 2. Install Dependencies

```
npm install
```

### 3. Configure Firebase

- Go to [Firebase Console](https://console.firebase.google.com/) and create a new project.
- Enable **Authentication** (Email/Password), **Firestore Database**, and **Storage**.
- In `firebase/firebaseConfig.ts`, replace the following with your Firebase project credentials:
  ```ts
  const firebaseConfig = {
    apiKey: 'YOUR_API_KEY',
    authDomain: 'YOUR_AUTH_DOMAIN',
    projectId: 'YOUR_PROJECT_ID',
    storageBucket: 'YOUR_STORAGE_BUCKET',
    messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
    appId: 'YOUR_APP_ID',
  };
  ```

### 4. Run the App

```
npx expo start
```

- Use the Expo Go app on your device or an emulator to preview.

## Notes

- All Firebase integrations (Auth, Firestore, Storage) are fully implemented with real-time updates and error handling.
- The app uses modular hooks and components for maintainability.
- Profile images are stored in Firebase Storage under `profiles/{uid}`.
- Tasks are stored in Firestore under the `tasks` collection, each with a `uid` field for user-specific data.

## Dependencies

- Expo
- React Native
- TypeScript
- Firebase
- @react-navigation/native, @react-navigation/bottom-tabs
- react-native-screens, react-native-safe-area-context, react-native-gesture-handler, react-native-reanimated
- react-native-vector-icons
- expo-image-picker

---

**Enjoy your new To-Do App!**
